1. Install python from official site (Check "add python to path" when installing)
2. Open cmd in the folder where the bot is
3. Install all requirements running this command: pip install -r requirements
4. Open config.yml using notepad or any other text editor
5. Fill in all fields in config
6. Run bot using this command: py main.py
7. Enjoy your new Nitro Dropper Bot!!!